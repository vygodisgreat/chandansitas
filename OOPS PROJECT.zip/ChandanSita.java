public class ChandanSita
{
    public static void main(String[] args)
    {
        new Lgf();
    }
}

//  where program?